//
//  main.cpp
//  Shell
//
//  Created by Chunhao on 2023/2/9.
//

#include <iostream>
#include <sstream>
#include <map>
#include "shelpers.hpp"
#include <readline/readline.h>



int main(int argc, const char * argv[]) {

   
    while(true){
        // use readline() for tab completion
        std::string path = currentPath();
        std::string shellString;
        shellString.append("@MyUnixShell  ");
        shellString.append(path);
        shellString.append("> ");
        std::string input = readline(shellString.c_str());

        // if user type exit, then end the shell program
        if(input == "exit"){
            exit(0);
        }
        
        // parse input commands
        std::vector<std::string> tokens = tokenize(input);
        std::vector<Command> cmds = getCommands(tokens);
        

        // if the command is cd, handle it in the parent process, don't create child
        if(cmds[0].exec == "cd"){
            if(cmds[0].argv.size() == 2 || strcmp(cmds[0].argv[1], "~") == 0){
                if(chdir(getenv("HOME")) == -1){
                    perror("fail at chdir\n");
                    continue;
                }
            }
            else{
                if(chdir(cmds[0].argv[1]) == -1){
                    perror("fail at chdir\n");
                    continue;
                }
            }
        }
        else if(cmds[0].setEV){
            //do nothing when setting environment variable
        }
        else{
            for(int i = 0; i < cmds.size(); i ++){
                
                Command cmd = cmds[i];
                int rc = fork();
                
                if (rc < 0) {
                    // fork failed; exit
                    perror("fork failed\n");
                    exit(1);
                }
                else if (rc == 0) { // child (new process)
                    // if it's background, fork another child and update the status when the background process is done
                    if(cmd.background){
                      
                        int pid = fork();
                        if(pid < 0){
                            // fork failed; exit
                            perror("fork failed\n");
                            exit(1);
                        }
                        else if(pid == 0){
                            // redirect to file
                            if(cmd.fdStdout != 1){
                                if(dup2(cmd.fdStdout, 1) == -1){
                                    perror("dup failed\n");
                                    exit(1);
                                }
                            }
                            if(cmd.fdStdin != 0){
                                if(dup2(cmd.fdStdin, 0) == -1){
                                    perror("dup failed\n");
                                    exit(1);
                                }
                            }
                            execvp(cmd.exec.c_str(), const_cast<char* const*>(cmd.argv.data()));
                            perror("execvp fail");
                            exit(1);
                        }
                        else{
                            int status;
                            waitpid(pid, &status, 0);
                            printf("[%d] + done    %s\n", getpid(), cmd.exec.c_str());
                            exit(0);
                        }
                    }
                    else{
                        // if it's not background
                        // redirect to file
                        if(cmd.fdStdout != 1){
                            if(dup2(cmd.fdStdout, 1) == -1){
                                perror("dup failed\n");
                                exit(1);
                            }
                        }
                        if(cmd.fdStdin != 0){
                            if(dup2(cmd.fdStdin, 0) == -1){
                                perror("dup failed\n");
                                exit(1);
                            }
                        }
                        execvp(cmd.exec.c_str(), const_cast<char* const*>(cmd.argv.data()));
                        perror("execvp fail");
                        exit(1);
                    }
                }
                else { // parent
                    
                    int status;
                    // close the fd
                    if(cmd.fdStdin!=0)
                        if(close(cmd.fdStdin) == -1){
                            perror("fail to close fd");
                            exit(1);
                        }
                    if(cmd.fdStdout!=1)
                        if(close(cmd.fdStdout) == -1){
                            perror("fail to close fd");
                            exit(1);
                        }
                    
                    // wait child if it's not a background
                    if(!cmd.background ){
                        waitpid(rc, &status, 0);
                    }
                    else{
                        printf("[background pid : %d]\n", rc );
                    }
                }
            }
        }
    }
    return 0;
}


